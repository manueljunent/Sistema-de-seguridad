HCSR501.h
#ifndef HCSR501_H
#define HCSR501_H

#include "driver/gpio.h"

void hcsr501_init(gpio_num_t pin);
bool hcsr501_detected(void);

#endif


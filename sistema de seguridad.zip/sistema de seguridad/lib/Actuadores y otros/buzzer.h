#ifndef BUZZER_H
#define BUZZER_H

#include "driver/gpio.h"

void buzzer_init(gpio_num_t pin);
void buzzer_on(void);
void buzzer_off(void);

#endif

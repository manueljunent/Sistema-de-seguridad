#ifndef RELAY_H
#define RELAY_H

#include "driver/gpio.h"

void relay_init(gpio_num_t pin);
void relay_on(void);
void relay_off(void);

#endif

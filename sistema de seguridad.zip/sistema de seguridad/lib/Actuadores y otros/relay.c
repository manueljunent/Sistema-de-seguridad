#include "Relay.h"

static gpio_num_t relay_pin;

void relay_init(gpio_num_t pin) {
    relay_pin = pin;
    gpio_set_direction(relay_pin, GPIO_MODE_OUTPUT);
    gpio_set_level(relay_pin, 0); // Default OFF
}

void relay_on(void) {
    gpio_set_level(relay_pin, 1);
}

void relay_off(void) {
    gpio_set_level(relay_pin, 0);
}

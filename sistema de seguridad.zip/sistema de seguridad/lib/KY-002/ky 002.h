KY002.h
#ifndef KY002_H
#define KY002_H

#include "driver/gpio.h"

void ky002_init(gpio_num_t pin);
bool ky002_detected(void);

#endif



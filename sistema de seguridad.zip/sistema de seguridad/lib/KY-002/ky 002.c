KY002.c
#include "KY002.h"

static gpio_num_t ky002_pin;

void ky002_init(gpio_num_t pin) {
    ky002_pin = pin;
    gpio_set_direction(ky002_pin, GPIO_MODE_INPUT);
}

bool ky002_detected(void) {
    return gpio_get_level(ky002_pin) == 1;
}
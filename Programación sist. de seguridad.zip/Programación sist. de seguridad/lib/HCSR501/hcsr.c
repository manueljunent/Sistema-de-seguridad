HCSR501.c
#include "HCSR501.h"

static gpio_num_t hcsr501_pin;

void hcsr501_init(gpio_num_t pin) {
    hcsr501_pin = pin;
    gpio_set_direction(hcsr501_pin, GPIO_MODE_INPUT);
}

bool hcsr501_detected(void) {
    return gpio_get_level(hcsr501_pin) == 1;
}

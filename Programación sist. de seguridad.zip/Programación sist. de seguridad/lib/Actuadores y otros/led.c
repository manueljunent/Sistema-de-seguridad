#include "LED.h"

static gpio_num_t led_pin;

void led_init(gpio_num_t pin) {
    led_pin = pin;
    gpio_set_direction(led_pin, GPIO_MODE_OUTPUT);
    gpio_set_level(led_pin, 0); // Default OFF
}

void led_on(void) {
    gpio_set_level(led_pin, 1);
}

void led_off(void) {
    gpio_set_level(led_pin, 0);
}

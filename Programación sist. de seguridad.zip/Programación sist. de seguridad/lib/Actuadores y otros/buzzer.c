#include "Buzzer.h"

static gpio_num_t buzzer_pin;

void buzzer_init(gpio_num_t pin) {
    buzzer_pin = pin;
    gpio_set_direction(buzzer_pin, GPIO_MODE_OUTPUT);
    gpio_set_level(buzzer_pin, 0); // Default OFF
}

void buzzer_on(void) {
    gpio_set_level(buzzer_pin, 1);
}

void buzzer_off(void) {
    gpio_set_level(buzzer_pin, 0);
}

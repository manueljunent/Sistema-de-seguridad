#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "KY002.h"
#include "HCSR501.h"
#include "Relay.h"
#include "Buzzer.h"
#include "LED.h"
#include "WiFi.h"
#include <PubSubClient.h>

// WiFi and MQTT configuration
#define WIFI_SSID "wifi_ssid"
#define WIFI_PASSWORD "wifi_password"
#define MQTT_BROKER "mqtt_broker_ip"
#define MQTT_TOPIC "alerta de seguridad"

static QueueHandle_t event_queue;

// GPIO pins 
#define KY002_PIN GPIO_NUM_4
#define HCSR501_PIN GPIO_NUM_5
#define RELAY_PIN GPIO_NUM_18
#define BUZZER_PIN GPIO_NUM_19
#define LED_PIN GPIO_NUM_2

// Cliente MQTT
WiFiClient espClient;
PubSubClient client(espClient);

void wifi_connect(void) {
    wifi_init_sta(WIFI_SSID, WIFI_PASSWORD);
    printf("Conectado a Wifi\n");
}

void mqtt_connect(void) {
    client.setServer(MQTT_BROKER, 1883);
    while (!client.connected()) {
        printf("Conectando al broker MQTT\n");
        if (client.connect("ESP32Client")) {
            printf("Conectado al broker MQTT\n");
        } else {
            printf("Error al conectar...Intentando nuevamente\n");
            vTaskDelay(pdMS_TO_TICKS(2000));
        }
    }
}

void send_mqtt_alert(const char *message) {
    if (client.connected()) {
        client.publish(MQTT_TOPIC, message);
        printf("Alerta enviada: %s\n", message);
    } else {
        printf("MQTT noo conectando. No es posible enviar la alerta\n");
    }
}

void sensor_task(void *arg) {
    while (1) {
        if (ky002_detected() && hcsr501_detected()) {
            printf("Ambos sensores han detectado algo!\n");
            xQueueSend(event_queue, "ALERTA", portMAX_DELAY);
        }
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

void event_handler_task(void *arg) {
    char event[32];
    while (1) {
        if (xQueueReceive(event_queue, &event, portMAX_DELAY)) {
            if (strcmp(event, "ALERTA") == 0) {
                relay_on();
                buzzer_on();
                led_on();
                send_mqtt_alert("Infracción de seguridad detectada!");
                vTaskDelay(pdMS_TO_TICKS(5000)); // Mantiene la alarma activada por 5 seg.
                relay_off();
                buzzer_off();
                led_off();
            }
        }
    }
}

void app_main(void) {
    printf("Sistema inicializándose\n");

    // Inicializa componentes
    ky002_init(KY002_PIN);
    hcsr501_init(HCSR501_PIN);
    relay_init(RELAY_PIN);
    buzzer_init(BUZZER_PIN);
    led_init(LED_PIN);

    // Conectar a wifi y al mqtt
    wifi_connect();
    mqtt_connect();

    // Crea una cola de eventos
    event_queue = xQueueCreate(10, sizeof(char[32]));

    // Crea tasks
    xTaskCreate(sensor_task, "SensorTask", 2048, NULL, 5, NULL);
    xTaskCreate(event_handler_task, "EventHandlerTask", 2048, NULL, 5, NULL);
}
